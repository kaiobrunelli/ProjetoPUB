using PlataformaNotificacao;
using SipubDesembolsos.Shared;

namespace SipubDesembolsos.Server.Eventos.Desembolso;

// Rejeitado → notifica apenas a coordenação responsável pelo desembolso
public class NotificarRejeicaoHandler(INotificacaoService notificacao)
    : IEventHandler<DesembolsoRejeitadoEvento>
{
    public async Task HandleAsync(DesembolsoRejeitadoEvento e)
    {
        await notificacao.EnviarCoordenacaoAsync(
            codigoCoordenacao: e.CoordenaçãoResponsavel,
            titulo:           $"Desembolso {e.DesembolsoId} rejeitado",
            mensagem:         $"Rejeitado por {e.UsuarioNome}. Verifique a pendência.",
            tipo:             TipoNotificacao.Alerta,
            codigoAplicativo: CodigoAplicativo.Sipub,
            link:             $"/?contratoId={e.DesembolsoId}"
        );
    }
}
