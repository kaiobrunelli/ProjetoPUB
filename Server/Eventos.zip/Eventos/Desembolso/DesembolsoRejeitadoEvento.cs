namespace SipubDesembolsos.Server.Eventos.Desembolso;

public record DesembolsoRejeitadoEvento(
    string DesembolsoId,
    string UsuarioId,
    string UsuarioNome,
    string CoordenaçãoResponsavel
);
